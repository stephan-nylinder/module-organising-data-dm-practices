## Licence declation file

All contents in this project folder fall under the CC-BY 4.0 licence for use and replication. 

Research data from this project desposited in the ENA repository abide to the terms and conditions stated there (https://www.ebi.ac.uk/licencing).