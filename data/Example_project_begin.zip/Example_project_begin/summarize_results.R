data <- data.frame(x1 = 1:5,    # Create example data frame
                   x2 = letters[1:5],
                   x3 = 3)
data                            # Print example data frame
#   x1 x2 x3
# 1  1  a  3
# 2  2  b  3
# 3  3  c  3
# 4  4  d  3
# 5  5  e  3